package com.wipro.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ChangeServlet")
public class ChangeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Password=request.getParameter("current");
		String Newpass=request.getParameter("new");
		String conpass=request.getParameter("confirm");
		String connurl = "jdbc:mysql://localhost:3306/loginmodule";
		Connection con=null;
		String pass="";
		int id=0;
		try{
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(connurl, "root", "12345");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from loginmodule where password='"+Password+"'");
		while(rs.next()){
		id=rs.getInt(1);
		pass=rs.getString(3);
		}
		System.out.println(id+ " "+pass);
		if(pass.equals(Password)){
		Statement st1=con.createStatement();
		int i=st1.executeUpdate("update login set password='"+Newpass+"' where id='"+id+"'");
		System.out.println("Password changed successfully");
		st1.close();
		con.close();
		}
		else{
		System.out.println("Invalid Current Password");
		}
		}
		catch(Exception e){
		e.printStackTrace();
		}
	}

	

}
